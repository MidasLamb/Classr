package main;

//import java.lang.reflect.Method;
//
//import org.junit.runner.Computer;
//import org.junit.runner.JUnitCore;
//
//import canvaswindow.VisualTests;
//import junit.framework.Test;


/**
 * A Class to update all visual tests. Mostly used to automatically recreate all
 * tests when we know everything is ok and only a visual update happened.
 * 
 * @author Groep11
 *
 */
public class VisualTestUpdater {

	public static boolean update = false;
	
	public static void main(String[] args) {
//		
//		VisualTestUpdater.update = true;
//		
//		Computer computer = new Computer();
//
//		JUnitCore jUnitCore = new JUnitCore();
//		jUnitCore.run(computer, canvaswindow.VisualTests.class);
	}
}
