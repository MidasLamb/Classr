package gui.form.base;

import java.awt.Graphics;

public abstract class State {

	abstract void draw(Graphics g);

}
