package gui.form.base;

public abstract class RadioButtonState extends State {

}
