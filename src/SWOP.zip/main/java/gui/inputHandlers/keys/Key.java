package gui.inputHandlers.keys;

/**
 * Abstract class that represents a keystroke.
 */
public abstract class Key {
	
}
